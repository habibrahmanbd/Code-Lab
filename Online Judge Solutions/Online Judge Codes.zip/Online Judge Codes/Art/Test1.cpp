#include<stdio.h>
int main()
{
    char digits[100];
    scanf("%[habib]",&digits);
    printf("Digits are %s\n",digits);
    return 0;
}
