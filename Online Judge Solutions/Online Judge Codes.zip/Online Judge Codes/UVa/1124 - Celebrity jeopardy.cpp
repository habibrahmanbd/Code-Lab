#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<math.h>
int main()
{
    char str[255];
    while(gets(str))
    puts(str);
    return 0;
}
