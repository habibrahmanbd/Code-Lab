#include<stdio.h>
int main()
{

}
mergepass(a,n,l,b)
{
    q=(n/(2*l));
    s=2*l*q;
    r=n-s;

}
